

let age = 25;
const name = "John";
age = 26;
name = "Jane";
// 여기에 설명해보세요 

// const 라는 부분은 변수를 통제하는 부분인데, const name = "John" 은 name 이라는 공간에 John 만 들어갈 수 있도록 셋팅한 것인데
// 문제에서는 name에  John이 아닌, Jane이 들어감으로서 에러가 뜬다.